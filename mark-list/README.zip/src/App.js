
import './App.css';
import Mainfile from './Mainfile';
import { BrowserRouter as Router} from 'react-router-dom';

function App() {
  return (
    <Router>
      <div>
      <Mainfile />
    </div>
    </Router>
    
  );
}

export default App;