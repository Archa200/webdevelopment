import { useState } from 'react';
import { useHistory ,withRouter} from 'react-router-dom';
// import Home from './Home';

const Mainfile = () => {
  const [name, setName] = useState('');
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);
  let history = useHistory();

  const handleInput = (e) => {
    const studentName = e.target.value;
    setName(studentName);
    setIsButtonDisabled(!studentName.trim());
  };

  const handleClick = () => {
    console.log('Adding student name');
    console.log(history)
    history.push("/Home");
  };

  return (

      <div>
        <label>
          Enter student name:
          <input
            type='text'
            value={name}
            onChange={handleInput}
          />
        </label>
        <button onClick={handleClick} disabled={isButtonDisabled}>
          Add
        </button>
      </div>
  );
};

export default withRouter(Mainfile) ;
