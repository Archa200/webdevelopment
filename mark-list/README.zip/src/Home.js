import React,{ useState} from "react";

const Home = () => {
const [marks,setMarks]=useState({
    Maths:'',
    Maths_II:'',
    Science:'',
    ML:'',
    ACN:'',
    Lab_1:'',
    Lab_2:''
    })

    const handleMark = (e, subject) => {
        const value = e.target.value;
        setMarks((new_marks) => ({
            ...new_marks,
            [subject]: value,
        }));
    };
    
const handleSubmit=()=>{
    console.log('Marks are submitted');
}
    return (
        <div>
            <h1>Add Marks</h1>
            <label>
            Maths:
                <input
                    type="number"
                    value={marks.Maths}
                    onChange={(e) => handleMark(e, 'Maths')}
                />
            </label>
            <label>
            Maths II:
                <input
                    type="number"
                    value={marks.Maths_II}
                    onChange={(e) => handleMark(e, 'Maths_II')}
                />
            </label>
            <label>
            Science:
                <input
                    type="number"
                    value={marks.Science}
                    onChange={(e) => handleMark(e, 'Science')}
                />
            </label>
            <label>
            ML:
                <input
                    type="number"
                    value={marks.ML}
                    onChange={(e) => handleMark(e, 'ML')}
                />
            </label>
            <label>
            ACN:
                <input
                    type="number"
                    value={marks.ACN}
                    onChange={(e) => handleMark(e, 'ACN')}
                />
            </label>
            <label>
            Lab_1:
                <input
                    type="number"
                    value={marks.Lab_1}
                    onChange={(e) => handleMark(e, 'Lab_1')}
                />
            </label>
            <label>
            Lab_2:
                <input
                    type="number"
                    value={marks.Lab_2}
                    onChange={(e) => handleMark(e, 'Lab_2')}
                />
            </label>
            <button onClick={handleSubmit}>Submit</button>
        </div>
        
     );
}
 
export default Home;